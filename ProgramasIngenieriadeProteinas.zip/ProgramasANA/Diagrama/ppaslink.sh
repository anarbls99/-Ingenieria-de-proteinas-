#!/bin/sh
DoExitAsm ()
{ echo "An error occurred while assembling $1"; exit 1; }
DoExitLink ()
{ echo "An error occurred while linking $1"; exit 1; }
OFS=$IFS
IFS="
"
/Applications/Xcode.app/Contents/Developer/usr/bin/ld     -framework Cocoa      -multiply_defined suppress -L. -o '/Users/anaroblesfernandez/Desktop/Ingeniería Proteínas/Diagrama/project1' `cat '/Users/anaroblesfernandez/Desktop/Ingeniería Proteínas/Diagrama/link.res'` -filelist '/Users/anaroblesfernandez/Desktop/Ingeniería Proteínas/Diagrama/linkfiles.res'
if [ $? != 0 ]; then DoExitLink ; fi
IFS=$OFS
